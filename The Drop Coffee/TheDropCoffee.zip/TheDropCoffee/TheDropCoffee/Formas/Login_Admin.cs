﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheDropCoffee.Formas
{
    public partial class Login_Empleados : Form
    {
        public Login_Empleados()
        {
            InitializeComponent();
            Clases.CConexiòn obj = new Clases.CConexiòn();
            obj.establecerConexión();
            //btnIniciarseciònEmpleado.Enabled = false;
        }
        public void btnIniciarseciònEmpleado_Click(object sender, EventArgs e)
        {
            Clases.Personal obj = new Clases.Personal();
            obj.Administradores(txtUsuarioAdmin, txtPasswordAdmin);
        }
        private void txtPasswordAdmin_Leave(object sender, EventArgs e)
        {
            if (txtPasswordAdmin.Texts == "")
            {
                txtPasswordAdmin.PasswordChar = false; 
                txtPasswordAdmin.Texts = "Ingrese Contraseña"; 
            }
        }
        private void txtUsuarioAdmin_Leave(object sender, EventArgs e)
        {
            if (txtUsuarioAdmin.Texts == "")
            {
                txtUsuarioAdmin.Texts = "Ingrese Usuario";
            }
        }
        private void txtUsuarioAdmin_Enter(object sender, EventArgs e)
        {
            if (txtUsuarioAdmin.Texts == "Ingrese Usuario")
            {
                txtUsuarioAdmin.Texts = "";
                txtUsuarioAdmin.ForeColor = Color.Black;
            }
        }
        private void txtPasswordAdmin_Enter(object sender, EventArgs e)
        {
            if (txtPasswordAdmin.Texts == "Ingrese Contraseña")
            {
                txtPasswordAdmin.Texts = "";
                txtPasswordAdmin.PasswordChar = true;
            }
        }
    }
}