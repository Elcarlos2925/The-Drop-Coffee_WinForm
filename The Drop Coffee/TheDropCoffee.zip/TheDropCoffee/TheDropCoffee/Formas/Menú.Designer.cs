﻿namespace TheDropCoffee
{
    partial class Menú
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menú));
            this.lablCantidadTeaMatcha = new System.Windows.Forms.Label();
            this.lablCantidadBrownie = new System.Windows.Forms.Label();
            this.lablPrecioBrownie = new System.Windows.Forms.Label();
            this.bttnMasBrownie = new System.Windows.Forms.Button();
            this.grpBBrownie = new System.Windows.Forms.GroupBox();
            this.bttnMenosBrownie = new System.Windows.Forms.Button();
            this.bttnInfoBrownie = new System.Windows.Forms.Button();
            this.btnBrownie = new System.Windows.Forms.Button();
            this.grpBGalleta = new System.Windows.Forms.GroupBox();
            this.lablCantidadGalleta = new System.Windows.Forms.Label();
            this.bttnMasGallleta = new System.Windows.Forms.Button();
            this.bttnMenosGalleta = new System.Windows.Forms.Button();
            this.lablPrecioGalleta = new System.Windows.Forms.Label();
            this.bttnInfoGalleta = new System.Windows.Forms.Button();
            this.btnGalleta = new System.Windows.Forms.Button();
            this.btnFrappucciono = new System.Windows.Forms.Button();
            this.bttnMasFrapuccino = new System.Windows.Forms.Button();
            this.bttnMenosFrapuccino = new System.Windows.Forms.Button();
            this.lablCantidadFrapuccino = new System.Windows.Forms.Label();
            this.lablPrecioFrappucciono = new System.Windows.Forms.Label();
            this.grpBFrappucciono = new System.Windows.Forms.GroupBox();
            this.bttnInfoFrappucciono = new System.Windows.Forms.Button();
            this.BtnCompletarPedido = new System.Windows.Forms.Button();
            this.bttnMasTeaMatcha = new System.Windows.Forms.Button();
            this.GrpBxBebidasFrias = new System.Windows.Forms.GroupBox();
            this.grpBTeaMatcha = new System.Windows.Forms.GroupBox();
            this.bttnMenosTeaMatcha = new System.Windows.Forms.Button();
            this.lablPrecioTeaMatcha = new System.Windows.Forms.Label();
            this.bttnInfoTeaMatcha = new System.Windows.Forms.Button();
            this.btnTeaMatcha = new System.Windows.Forms.Button();
            this.grpBAmericano = new System.Windows.Forms.GroupBox();
            this.lablCantidadAmericano = new System.Windows.Forms.Label();
            this.bttnMasAmericano = new System.Windows.Forms.Button();
            this.bttnMenosAmericano = new System.Windows.Forms.Button();
            this.lablPrecioAmericano = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.btnAmericano = new System.Windows.Forms.Button();
            this.grpBCappucino = new System.Windows.Forms.GroupBox();
            this.lablCantidadCapuccino = new System.Windows.Forms.Label();
            this.lablPrecioCappucino = new System.Windows.Forms.Label();
            this.bttnMasCapuccino = new System.Windows.Forms.Button();
            this.bttnInfoCappucino = new System.Windows.Forms.Button();
            this.bttnMenosCappuccino = new System.Windows.Forms.Button();
            this.btnCappucino = new System.Windows.Forms.Button();
            this.grpBWhiteMocha = new System.Windows.Forms.GroupBox();
            this.lablCantidadWhiteMocha = new System.Windows.Forms.Label();
            this.bttnMasWhiteMocha = new System.Windows.Forms.Button();
            this.bttnMenosWhiteMocha = new System.Windows.Forms.Button();
            this.lablPrecioWhiteMocha = new System.Windows.Forms.Label();
            this.bttnInfoWhiteMocha = new System.Windows.Forms.Button();
            this.btnWhiteMocha = new System.Windows.Forms.Button();
            this.grpBLatte = new System.Windows.Forms.GroupBox();
            this.lablCantidadLatte = new System.Windows.Forms.Label();
            this.bttnMasLatte = new System.Windows.Forms.Button();
            this.lablPrecioLatte = new System.Windows.Forms.Label();
            this.bttnMenosLatte = new System.Windows.Forms.Button();
            this.bttnInfoLatte = new System.Windows.Forms.Button();
            this.btnLatte = new System.Windows.Forms.Button();
            this.grpBPastel = new System.Windows.Forms.GroupBox();
            this.lablCantidadPastel = new System.Windows.Forms.Label();
            this.lablPrecioPastel = new System.Windows.Forms.Label();
            this.bttnMasPastel = new System.Windows.Forms.Button();
            this.bttbInfoPastel = new System.Windows.Forms.Button();
            this.bttnMenosPastel = new System.Windows.Forms.Button();
            this.btnPastel = new System.Windows.Forms.Button();
            this.grpBChocolate = new System.Windows.Forms.GroupBox();
            this.lablCantidadChocolate = new System.Windows.Forms.Label();
            this.bttnMasChocolate = new System.Windows.Forms.Button();
            this.bttnMenosChocolate = new System.Windows.Forms.Button();
            this.lablPrecioChocolate = new System.Windows.Forms.Label();
            this.bttnInfoChocolate = new System.Windows.Forms.Button();
            this.btnChocolate = new System.Windows.Forms.Button();
            this.grpBSandwich = new System.Windows.Forms.GroupBox();
            this.labelCantidadSandwich = new System.Windows.Forms.Label();
            this.bttnMasSandwich = new System.Windows.Forms.Button();
            this.bttnMenosSandwich = new System.Windows.Forms.Button();
            this.lablPrecioSandwich = new System.Windows.Forms.Label();
            this.bttnInfoSandwich = new System.Windows.Forms.Button();
            this.btnSandwich = new System.Windows.Forms.Button();
            this.grpBMocha = new System.Windows.Forms.GroupBox();
            this.lablCantidadMocha = new System.Windows.Forms.Label();
            this.bttnMasMocha = new System.Windows.Forms.Button();
            this.bttnMenosMocha = new System.Windows.Forms.Button();
            this.lablPrecioMocha = new System.Windows.Forms.Label();
            this.bttnInfoMocha = new System.Windows.Forms.Button();
            this.btnMocha = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnCancelarPedido = new System.Windows.Forms.Button();
            this.dTPFecha = new System.Windows.Forms.DateTimePicker();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.labelTotal = new System.Windows.Forms.Label();
            this.txtMostrarTotal = new System.Windows.Forms.TextBox();
            this.RTxtTicket = new System.Windows.Forms.RichTextBox();
            this.GrpBxAlimentos = new System.Windows.Forms.GroupBox();
            this.GrpBxBebidasCalientes = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bntPedidoPara = new System.Windows.Forms.Button();
            this.cmbPedido = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.datagribview1 = new System.Windows.Forms.DataGridView();
            this.grpBBrownie.SuspendLayout();
            this.grpBGalleta.SuspendLayout();
            this.grpBFrappucciono.SuspendLayout();
            this.GrpBxBebidasFrias.SuspendLayout();
            this.grpBTeaMatcha.SuspendLayout();
            this.grpBAmericano.SuspendLayout();
            this.grpBCappucino.SuspendLayout();
            this.grpBWhiteMocha.SuspendLayout();
            this.grpBLatte.SuspendLayout();
            this.grpBPastel.SuspendLayout();
            this.grpBChocolate.SuspendLayout();
            this.grpBSandwich.SuspendLayout();
            this.grpBMocha.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.GrpBxAlimentos.SuspendLayout();
            this.GrpBxBebidasCalientes.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagribview1)).BeginInit();
            this.SuspendLayout();
            // 
            // lablCantidadTeaMatcha
            // 
            this.lablCantidadTeaMatcha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadTeaMatcha.AutoSize = true;
            this.lablCantidadTeaMatcha.Location = new System.Drawing.Point(55, 125);
            this.lablCantidadTeaMatcha.Name = "lablCantidadTeaMatcha";
            this.lablCantidadTeaMatcha.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadTeaMatcha.TabIndex = 11;
            this.lablCantidadTeaMatcha.Text = "0";
            // 
            // lablCantidadBrownie
            // 
            this.lablCantidadBrownie.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadBrownie.AutoSize = true;
            this.lablCantidadBrownie.Location = new System.Drawing.Point(58, 130);
            this.lablCantidadBrownie.Name = "lablCantidadBrownie";
            this.lablCantidadBrownie.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadBrownie.TabIndex = 17;
            this.lablCantidadBrownie.Text = "0";
            // 
            // lablPrecioBrownie
            // 
            this.lablPrecioBrownie.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioBrownie.AutoSize = true;
            this.lablPrecioBrownie.Location = new System.Drawing.Point(18, 178);
            this.lablPrecioBrownie.Name = "lablPrecioBrownie";
            this.lablPrecioBrownie.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioBrownie.TabIndex = 2;
            this.lablPrecioBrownie.Text = "35.00";
            // 
            // bttnMasBrownie
            // 
            this.bttnMasBrownie.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasBrownie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasBrownie.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasBrownie.ForeColor = System.Drawing.Color.Black;
            this.bttnMasBrownie.Location = new System.Drawing.Point(85, 126);
            this.bttnMasBrownie.Name = "bttnMasBrownie";
            this.bttnMasBrownie.Size = new System.Drawing.Size(30, 30);
            this.bttnMasBrownie.TabIndex = 16;
            this.bttnMasBrownie.Text = "+";
            this.bttnMasBrownie.UseVisualStyleBackColor = false;
            this.bttnMasBrownie.Click += new System.EventHandler(this.bttnMasBrownie_Click);
            // 
            // grpBBrownie
            // 
            this.grpBBrownie.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBBrownie.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBBrownie.Controls.Add(this.lablCantidadBrownie);
            this.grpBBrownie.Controls.Add(this.lablPrecioBrownie);
            this.grpBBrownie.Controls.Add(this.bttnMasBrownie);
            this.grpBBrownie.Controls.Add(this.bttnMenosBrownie);
            this.grpBBrownie.Controls.Add(this.bttnInfoBrownie);
            this.grpBBrownie.Controls.Add(this.btnBrownie);
            this.grpBBrownie.Location = new System.Drawing.Point(301, 50);
            this.grpBBrownie.Name = "grpBBrownie";
            this.grpBBrownie.Size = new System.Drawing.Size(129, 208);
            this.grpBBrownie.TabIndex = 7;
            this.grpBBrownie.TabStop = false;
            this.grpBBrownie.Text = "Brownie";
            // 
            // bttnMenosBrownie
            // 
            this.bttnMenosBrownie.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosBrownie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosBrownie.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosBrownie.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosBrownie.Location = new System.Drawing.Point(13, 126);
            this.bttnMenosBrownie.Name = "bttnMenosBrownie";
            this.bttnMenosBrownie.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosBrownie.TabIndex = 15;
            this.bttnMenosBrownie.Text = "-";
            this.bttnMenosBrownie.UseVisualStyleBackColor = false;
            this.bttnMenosBrownie.Click += new System.EventHandler(this.bttnMenosBrownie_Click);
            // 
            // bttnInfoBrownie
            // 
            this.bttnInfoBrownie.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoBrownie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoBrownie.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoBrownie.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoBrownie.Location = new System.Drawing.Point(93, 169);
            this.bttnInfoBrownie.Name = "bttnInfoBrownie";
            this.bttnInfoBrownie.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoBrownie.TabIndex = 1;
            this.bttnInfoBrownie.Text = "i";
            this.bttnInfoBrownie.UseVisualStyleBackColor = false;
            this.bttnInfoBrownie.Click += new System.EventHandler(this.bttnInfoBrownie_Click);
            // 
            // btnBrownie
            // 
            this.btnBrownie.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBrownie.BackColor = System.Drawing.Color.White;
            this.btnBrownie.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrownie.BackgroundImage")));
            this.btnBrownie.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnBrownie.Location = new System.Drawing.Point(13, 34);
            this.btnBrownie.Name = "btnBrownie";
            this.btnBrownie.Size = new System.Drawing.Size(102, 80);
            this.btnBrownie.TabIndex = 0;
            this.btnBrownie.UseVisualStyleBackColor = false;
            // 
            // grpBGalleta
            // 
            this.grpBGalleta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBGalleta.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBGalleta.Controls.Add(this.lablCantidadGalleta);
            this.grpBGalleta.Controls.Add(this.bttnMasGallleta);
            this.grpBGalleta.Controls.Add(this.bttnMenosGalleta);
            this.grpBGalleta.Controls.Add(this.lablPrecioGalleta);
            this.grpBGalleta.Controls.Add(this.bttnInfoGalleta);
            this.grpBGalleta.Controls.Add(this.btnGalleta);
            this.grpBGalleta.Location = new System.Drawing.Point(13, 50);
            this.grpBGalleta.Name = "grpBGalleta";
            this.grpBGalleta.Size = new System.Drawing.Size(128, 208);
            this.grpBGalleta.TabIndex = 6;
            this.grpBGalleta.TabStop = false;
            this.grpBGalleta.Text = "Galleta";
            // 
            // lablCantidadGalleta
            // 
            this.lablCantidadGalleta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadGalleta.AutoSize = true;
            this.lablCantidadGalleta.Location = new System.Drawing.Point(58, 130);
            this.lablCantidadGalleta.Name = "lablCantidadGalleta";
            this.lablCantidadGalleta.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadGalleta.TabIndex = 11;
            this.lablCantidadGalleta.Text = "0";
            // 
            // bttnMasGallleta
            // 
            this.bttnMasGallleta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasGallleta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasGallleta.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasGallleta.ForeColor = System.Drawing.Color.Black;
            this.bttnMasGallleta.Location = new System.Drawing.Point(82, 126);
            this.bttnMasGallleta.Name = "bttnMasGallleta";
            this.bttnMasGallleta.Size = new System.Drawing.Size(30, 30);
            this.bttnMasGallleta.TabIndex = 10;
            this.bttnMasGallleta.Text = "+";
            this.bttnMasGallleta.UseVisualStyleBackColor = false;
            this.bttnMasGallleta.Click += new System.EventHandler(this.bttnMasGallleta_Click);
            // 
            // bttnMenosGalleta
            // 
            this.bttnMenosGalleta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosGalleta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosGalleta.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosGalleta.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosGalleta.Location = new System.Drawing.Point(13, 125);
            this.bttnMenosGalleta.Name = "bttnMenosGalleta";
            this.bttnMenosGalleta.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosGalleta.TabIndex = 9;
            this.bttnMenosGalleta.Text = "-";
            this.bttnMenosGalleta.UseVisualStyleBackColor = false;
            this.bttnMenosGalleta.Click += new System.EventHandler(this.bttnMenosGalleta_Click);
            // 
            // lablPrecioGalleta
            // 
            this.lablPrecioGalleta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioGalleta.AutoSize = true;
            this.lablPrecioGalleta.Location = new System.Drawing.Point(18, 181);
            this.lablPrecioGalleta.Name = "lablPrecioGalleta";
            this.lablPrecioGalleta.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioGalleta.TabIndex = 2;
            this.lablPrecioGalleta.Text = "20.00";
            // 
            // bttnInfoGalleta
            // 
            this.bttnInfoGalleta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoGalleta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoGalleta.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoGalleta.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoGalleta.Location = new System.Drawing.Point(92, 172);
            this.bttnInfoGalleta.Name = "bttnInfoGalleta";
            this.bttnInfoGalleta.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoGalleta.TabIndex = 1;
            this.bttnInfoGalleta.Text = "i";
            this.bttnInfoGalleta.UseVisualStyleBackColor = false;
            this.bttnInfoGalleta.Click += new System.EventHandler(this.bttnInfoGalleta_Click);
            // 
            // btnGalleta
            // 
            this.btnGalleta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGalleta.BackColor = System.Drawing.Color.White;
            this.btnGalleta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGalleta.BackgroundImage")));
            this.btnGalleta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnGalleta.Location = new System.Drawing.Point(13, 34);
            this.btnGalleta.Name = "btnGalleta";
            this.btnGalleta.Size = new System.Drawing.Size(102, 80);
            this.btnGalleta.TabIndex = 0;
            this.btnGalleta.UseVisualStyleBackColor = false;
            // 
            // btnFrappucciono
            // 
            this.btnFrappucciono.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFrappucciono.BackColor = System.Drawing.Color.White;
            this.btnFrappucciono.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFrappucciono.BackgroundImage")));
            this.btnFrappucciono.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFrappucciono.Location = new System.Drawing.Point(17, 34);
            this.btnFrappucciono.Name = "btnFrappucciono";
            this.btnFrappucciono.Size = new System.Drawing.Size(102, 80);
            this.btnFrappucciono.TabIndex = 0;
            this.btnFrappucciono.UseVisualStyleBackColor = false;
            // 
            // bttnMasFrapuccino
            // 
            this.bttnMasFrapuccino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasFrapuccino.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasFrapuccino.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasFrapuccino.ForeColor = System.Drawing.Color.Black;
            this.bttnMasFrapuccino.Location = new System.Drawing.Point(89, 126);
            this.bttnMasFrapuccino.Name = "bttnMasFrapuccino";
            this.bttnMasFrapuccino.Size = new System.Drawing.Size(30, 30);
            this.bttnMasFrapuccino.TabIndex = 13;
            this.bttnMasFrapuccino.Text = "+";
            this.bttnMasFrapuccino.UseVisualStyleBackColor = false;
            this.bttnMasFrapuccino.Click += new System.EventHandler(this.bttnMasFrapuccino_Click);
            // 
            // bttnMenosFrapuccino
            // 
            this.bttnMenosFrapuccino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosFrapuccino.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosFrapuccino.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosFrapuccino.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosFrapuccino.Location = new System.Drawing.Point(17, 125);
            this.bttnMenosFrapuccino.Name = "bttnMenosFrapuccino";
            this.bttnMenosFrapuccino.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosFrapuccino.TabIndex = 12;
            this.bttnMenosFrapuccino.Text = "-";
            this.bttnMenosFrapuccino.UseVisualStyleBackColor = false;
            this.bttnMenosFrapuccino.Click += new System.EventHandler(this.bttnMenosFrapuccino_Click);
            // 
            // lablCantidadFrapuccino
            // 
            this.lablCantidadFrapuccino.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadFrapuccino.AutoSize = true;
            this.lablCantidadFrapuccino.Location = new System.Drawing.Point(60, 130);
            this.lablCantidadFrapuccino.Name = "lablCantidadFrapuccino";
            this.lablCantidadFrapuccino.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadFrapuccino.TabIndex = 14;
            this.lablCantidadFrapuccino.Text = "0";
            // 
            // lablPrecioFrappucciono
            // 
            this.lablPrecioFrappucciono.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioFrappucciono.AutoSize = true;
            this.lablPrecioFrappucciono.Location = new System.Drawing.Point(27, 181);
            this.lablPrecioFrappucciono.Name = "lablPrecioFrappucciono";
            this.lablPrecioFrappucciono.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioFrappucciono.TabIndex = 2;
            this.lablPrecioFrappucciono.Text = "85.00";
            // 
            // grpBFrappucciono
            // 
            this.grpBFrappucciono.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBFrappucciono.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBFrappucciono.Controls.Add(this.lablCantidadFrapuccino);
            this.grpBFrappucciono.Controls.Add(this.lablPrecioFrappucciono);
            this.grpBFrappucciono.Controls.Add(this.bttnMasFrapuccino);
            this.grpBFrappucciono.Controls.Add(this.bttnMenosFrapuccino);
            this.grpBFrappucciono.Controls.Add(this.bttnInfoFrappucciono);
            this.grpBFrappucciono.Controls.Add(this.btnFrappucciono);
            this.grpBFrappucciono.Location = new System.Drawing.Point(168, 50);
            this.grpBFrappucciono.Name = "grpBFrappucciono";
            this.grpBFrappucciono.Size = new System.Drawing.Size(136, 208);
            this.grpBFrappucciono.TabIndex = 6;
            this.grpBFrappucciono.TabStop = false;
            this.grpBFrappucciono.Text = "Frappucciono";
            // 
            // bttnInfoFrappucciono
            // 
            this.bttnInfoFrappucciono.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoFrappucciono.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoFrappucciono.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoFrappucciono.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoFrappucciono.Location = new System.Drawing.Point(98, 169);
            this.bttnInfoFrappucciono.Name = "bttnInfoFrappucciono";
            this.bttnInfoFrappucciono.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoFrappucciono.TabIndex = 1;
            this.bttnInfoFrappucciono.Text = "i";
            this.bttnInfoFrappucciono.UseVisualStyleBackColor = false;
            this.bttnInfoFrappucciono.Click += new System.EventHandler(this.bttnInfoFrappucciono_Click);
            // 
            // BtnCompletarPedido
            // 
            this.BtnCompletarPedido.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BtnCompletarPedido.Location = new System.Drawing.Point(136, 6);
            this.BtnCompletarPedido.Name = "BtnCompletarPedido";
            this.BtnCompletarPedido.Size = new System.Drawing.Size(81, 57);
            this.BtnCompletarPedido.TabIndex = 23;
            this.BtnCompletarPedido.Text = "Finalizar Pedido ✔";
            this.BtnCompletarPedido.UseVisualStyleBackColor = true;
            this.BtnCompletarPedido.Click += new System.EventHandler(this.BtnCompletarPedido_Click);
            // 
            // bttnMasTeaMatcha
            // 
            this.bttnMasTeaMatcha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasTeaMatcha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasTeaMatcha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasTeaMatcha.ForeColor = System.Drawing.Color.Black;
            this.bttnMasTeaMatcha.Location = new System.Drawing.Point(89, 120);
            this.bttnMasTeaMatcha.Name = "bttnMasTeaMatcha";
            this.bttnMasTeaMatcha.Size = new System.Drawing.Size(30, 30);
            this.bttnMasTeaMatcha.TabIndex = 10;
            this.bttnMasTeaMatcha.Text = "+";
            this.bttnMasTeaMatcha.UseVisualStyleBackColor = false;
            this.bttnMasTeaMatcha.Click += new System.EventHandler(this.bttnMasTeaMatcha_Click);
            // 
            // GrpBxBebidasFrias
            // 
            this.GrpBxBebidasFrias.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrpBxBebidasFrias.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(204)))), ((int)(((byte)(174)))));
            this.GrpBxBebidasFrias.Controls.Add(this.grpBTeaMatcha);
            this.GrpBxBebidasFrias.Controls.Add(this.grpBFrappucciono);
            this.GrpBxBebidasFrias.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpBxBebidasFrias.Location = new System.Drawing.Point(8, 311);
            this.GrpBxBebidasFrias.Name = "GrpBxBebidasFrias";
            this.GrpBxBebidasFrias.Size = new System.Drawing.Size(322, 286);
            this.GrpBxBebidasFrias.TabIndex = 24;
            this.GrpBxBebidasFrias.TabStop = false;
            this.GrpBxBebidasFrias.Text = "Bebidas frías";
            // 
            // grpBTeaMatcha
            // 
            this.grpBTeaMatcha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBTeaMatcha.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBTeaMatcha.Controls.Add(this.lablCantidadTeaMatcha);
            this.grpBTeaMatcha.Controls.Add(this.bttnMasTeaMatcha);
            this.grpBTeaMatcha.Controls.Add(this.bttnMenosTeaMatcha);
            this.grpBTeaMatcha.Controls.Add(this.lablPrecioTeaMatcha);
            this.grpBTeaMatcha.Controls.Add(this.bttnInfoTeaMatcha);
            this.grpBTeaMatcha.Controls.Add(this.btnTeaMatcha);
            this.grpBTeaMatcha.Location = new System.Drawing.Point(16, 50);
            this.grpBTeaMatcha.Name = "grpBTeaMatcha";
            this.grpBTeaMatcha.Size = new System.Drawing.Size(136, 208);
            this.grpBTeaMatcha.TabIndex = 5;
            this.grpBTeaMatcha.TabStop = false;
            this.grpBTeaMatcha.Text = "Tea Matcha";
            // 
            // bttnMenosTeaMatcha
            // 
            this.bttnMenosTeaMatcha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosTeaMatcha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosTeaMatcha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosTeaMatcha.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosTeaMatcha.Location = new System.Drawing.Point(19, 120);
            this.bttnMenosTeaMatcha.Name = "bttnMenosTeaMatcha";
            this.bttnMenosTeaMatcha.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosTeaMatcha.TabIndex = 9;
            this.bttnMenosTeaMatcha.Text = "-";
            this.bttnMenosTeaMatcha.UseVisualStyleBackColor = false;
            this.bttnMenosTeaMatcha.Click += new System.EventHandler(this.bttnMenosTeaMatcha_Click);
            // 
            // lablPrecioTeaMatcha
            // 
            this.lablPrecioTeaMatcha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioTeaMatcha.AutoSize = true;
            this.lablPrecioTeaMatcha.Location = new System.Drawing.Point(26, 181);
            this.lablPrecioTeaMatcha.Name = "lablPrecioTeaMatcha";
            this.lablPrecioTeaMatcha.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioTeaMatcha.TabIndex = 2;
            this.lablPrecioTeaMatcha.Text = "80.00";
            // 
            // bttnInfoTeaMatcha
            // 
            this.bttnInfoTeaMatcha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoTeaMatcha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoTeaMatcha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoTeaMatcha.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoTeaMatcha.Location = new System.Drawing.Point(100, 172);
            this.bttnInfoTeaMatcha.Name = "bttnInfoTeaMatcha";
            this.bttnInfoTeaMatcha.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoTeaMatcha.TabIndex = 1;
            this.bttnInfoTeaMatcha.Text = "i";
            this.bttnInfoTeaMatcha.UseVisualStyleBackColor = false;
            this.bttnInfoTeaMatcha.Click += new System.EventHandler(this.bttnInfoTeaMatcha_Click);
            // 
            // btnTeaMatcha
            // 
            this.btnTeaMatcha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnTeaMatcha.BackColor = System.Drawing.Color.White;
            this.btnTeaMatcha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTeaMatcha.BackgroundImage")));
            this.btnTeaMatcha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTeaMatcha.Location = new System.Drawing.Point(17, 34);
            this.btnTeaMatcha.Name = "btnTeaMatcha";
            this.btnTeaMatcha.Size = new System.Drawing.Size(102, 80);
            this.btnTeaMatcha.TabIndex = 0;
            this.btnTeaMatcha.UseVisualStyleBackColor = false;
            // 
            // grpBAmericano
            // 
            this.grpBAmericano.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBAmericano.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBAmericano.Controls.Add(this.lablCantidadAmericano);
            this.grpBAmericano.Controls.Add(this.bttnMasAmericano);
            this.grpBAmericano.Controls.Add(this.bttnMenosAmericano);
            this.grpBAmericano.Controls.Add(this.lablPrecioAmericano);
            this.grpBAmericano.Controls.Add(this.button2);
            this.grpBAmericano.Controls.Add(this.btnAmericano);
            this.grpBAmericano.Location = new System.Drawing.Point(29, 49);
            this.grpBAmericano.Name = "grpBAmericano";
            this.grpBAmericano.Size = new System.Drawing.Size(136, 208);
            this.grpBAmericano.TabIndex = 1;
            this.grpBAmericano.TabStop = false;
            this.grpBAmericano.Text = "Americano";
            // 
            // lablCantidadAmericano
            // 
            this.lablCantidadAmericano.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadAmericano.AutoSize = true;
            this.lablCantidadAmericano.Location = new System.Drawing.Point(60, 133);
            this.lablCantidadAmericano.Name = "lablCantidadAmericano";
            this.lablCantidadAmericano.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadAmericano.TabIndex = 5;
            this.lablCantidadAmericano.Text = "0";
            // 
            // bttnMasAmericano
            // 
            this.bttnMasAmericano.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasAmericano.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasAmericano.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasAmericano.ForeColor = System.Drawing.Color.Black;
            this.bttnMasAmericano.Location = new System.Drawing.Point(80, 124);
            this.bttnMasAmericano.Name = "bttnMasAmericano";
            this.bttnMasAmericano.Size = new System.Drawing.Size(30, 30);
            this.bttnMasAmericano.TabIndex = 4;
            this.bttnMasAmericano.Text = "+";
            this.bttnMasAmericano.UseVisualStyleBackColor = false;
            this.bttnMasAmericano.Click += new System.EventHandler(this.bttnMasAmericano_Click);
            // 
            // bttnMenosAmericano
            // 
            this.bttnMenosAmericano.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosAmericano.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosAmericano.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosAmericano.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosAmericano.Location = new System.Drawing.Point(16, 124);
            this.bttnMenosAmericano.Name = "bttnMenosAmericano";
            this.bttnMenosAmericano.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosAmericano.TabIndex = 3;
            this.bttnMenosAmericano.Text = "-";
            this.bttnMenosAmericano.UseVisualStyleBackColor = false;
            this.bttnMenosAmericano.Click += new System.EventHandler(this.bttnMenosAmericano_Click);
            // 
            // lablPrecioAmericano
            // 
            this.lablPrecioAmericano.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioAmericano.AutoSize = true;
            this.lablPrecioAmericano.Location = new System.Drawing.Point(14, 181);
            this.lablPrecioAmericano.Name = "lablPrecioAmericano";
            this.lablPrecioAmericano.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioAmericano.TabIndex = 2;
            this.lablPrecioAmericano.Text = "70.00";
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.button2.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Blue;
            this.button2.Location = new System.Drawing.Point(100, 172);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 30);
            this.button2.TabIndex = 1;
            this.button2.Text = "i";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAmericano
            // 
            this.btnAmericano.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAmericano.BackColor = System.Drawing.Color.White;
            this.btnAmericano.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAmericano.BackgroundImage")));
            this.btnAmericano.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAmericano.Location = new System.Drawing.Point(17, 34);
            this.btnAmericano.Name = "btnAmericano";
            this.btnAmericano.Size = new System.Drawing.Size(102, 80);
            this.btnAmericano.TabIndex = 0;
            this.btnAmericano.UseVisualStyleBackColor = false;
            // 
            // grpBCappucino
            // 
            this.grpBCappucino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBCappucino.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBCappucino.Controls.Add(this.lablCantidadCapuccino);
            this.grpBCappucino.Controls.Add(this.lablPrecioCappucino);
            this.grpBCappucino.Controls.Add(this.bttnMasCapuccino);
            this.grpBCappucino.Controls.Add(this.bttnInfoCappucino);
            this.grpBCappucino.Controls.Add(this.bttnMenosCappuccino);
            this.grpBCappucino.Controls.Add(this.btnCappucino);
            this.grpBCappucino.Location = new System.Drawing.Point(181, 49);
            this.grpBCappucino.Name = "grpBCappucino";
            this.grpBCappucino.Size = new System.Drawing.Size(132, 208);
            this.grpBCappucino.TabIndex = 3;
            this.grpBCappucino.TabStop = false;
            this.grpBCappucino.Text = "Cappucino";
            // 
            // lablCantidadCapuccino
            // 
            this.lablCantidadCapuccino.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadCapuccino.AutoSize = true;
            this.lablCantidadCapuccino.Location = new System.Drawing.Point(58, 134);
            this.lablCantidadCapuccino.Name = "lablCantidadCapuccino";
            this.lablCantidadCapuccino.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadCapuccino.TabIndex = 19;
            this.lablCantidadCapuccino.Text = "0";
            // 
            // lablPrecioCappucino
            // 
            this.lablPrecioCappucino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioCappucino.AutoSize = true;
            this.lablPrecioCappucino.Location = new System.Drawing.Point(22, 181);
            this.lablPrecioCappucino.Name = "lablPrecioCappucino";
            this.lablPrecioCappucino.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioCappucino.TabIndex = 2;
            this.lablPrecioCappucino.Text = "85.00";
            // 
            // bttnMasCapuccino
            // 
            this.bttnMasCapuccino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasCapuccino.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasCapuccino.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasCapuccino.ForeColor = System.Drawing.Color.Black;
            this.bttnMasCapuccino.Location = new System.Drawing.Point(81, 124);
            this.bttnMasCapuccino.Name = "bttnMasCapuccino";
            this.bttnMasCapuccino.Size = new System.Drawing.Size(30, 30);
            this.bttnMasCapuccino.TabIndex = 18;
            this.bttnMasCapuccino.Text = "+";
            this.bttnMasCapuccino.UseVisualStyleBackColor = false;
            this.bttnMasCapuccino.Click += new System.EventHandler(this.bttnMasCapuccino_Click);
            // 
            // bttnInfoCappucino
            // 
            this.bttnInfoCappucino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoCappucino.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoCappucino.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoCappucino.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoCappucino.Location = new System.Drawing.Point(96, 172);
            this.bttnInfoCappucino.Name = "bttnInfoCappucino";
            this.bttnInfoCappucino.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoCappucino.TabIndex = 1;
            this.bttnInfoCappucino.Text = "i";
            this.bttnInfoCappucino.UseVisualStyleBackColor = false;
            this.bttnInfoCappucino.Click += new System.EventHandler(this.bttnInfoCappucino_Click);
            // 
            // bttnMenosCappuccino
            // 
            this.bttnMenosCappuccino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosCappuccino.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosCappuccino.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosCappuccino.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosCappuccino.Location = new System.Drawing.Point(17, 124);
            this.bttnMenosCappuccino.Name = "bttnMenosCappuccino";
            this.bttnMenosCappuccino.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosCappuccino.TabIndex = 17;
            this.bttnMenosCappuccino.Text = "-";
            this.bttnMenosCappuccino.UseVisualStyleBackColor = false;
            this.bttnMenosCappuccino.Click += new System.EventHandler(this.bttnMenosCappuccino_Click);
            // 
            // btnCappucino
            // 
            this.btnCappucino.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCappucino.BackColor = System.Drawing.Color.White;
            this.btnCappucino.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCappucino.BackgroundImage")));
            this.btnCappucino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCappucino.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnCappucino.Location = new System.Drawing.Point(15, 34);
            this.btnCappucino.Name = "btnCappucino";
            this.btnCappucino.Size = new System.Drawing.Size(102, 80);
            this.btnCappucino.TabIndex = 0;
            this.btnCappucino.UseVisualStyleBackColor = false;
            // 
            // grpBWhiteMocha
            // 
            this.grpBWhiteMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBWhiteMocha.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBWhiteMocha.Controls.Add(this.lablCantidadWhiteMocha);
            this.grpBWhiteMocha.Controls.Add(this.bttnMasWhiteMocha);
            this.grpBWhiteMocha.Controls.Add(this.bttnMenosWhiteMocha);
            this.grpBWhiteMocha.Controls.Add(this.lablPrecioWhiteMocha);
            this.grpBWhiteMocha.Controls.Add(this.bttnInfoWhiteMocha);
            this.grpBWhiteMocha.Controls.Add(this.btnWhiteMocha);
            this.grpBWhiteMocha.Location = new System.Drawing.Point(466, 49);
            this.grpBWhiteMocha.Name = "grpBWhiteMocha";
            this.grpBWhiteMocha.Size = new System.Drawing.Size(129, 208);
            this.grpBWhiteMocha.TabIndex = 4;
            this.grpBWhiteMocha.TabStop = false;
            this.grpBWhiteMocha.Text = "White Mocha";
            // 
            // lablCantidadWhiteMocha
            // 
            this.lablCantidadWhiteMocha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadWhiteMocha.AutoSize = true;
            this.lablCantidadWhiteMocha.Location = new System.Drawing.Point(59, 134);
            this.lablCantidadWhiteMocha.Name = "lablCantidadWhiteMocha";
            this.lablCantidadWhiteMocha.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadWhiteMocha.TabIndex = 11;
            this.lablCantidadWhiteMocha.Text = "0";
            // 
            // bttnMasWhiteMocha
            // 
            this.bttnMasWhiteMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasWhiteMocha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasWhiteMocha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasWhiteMocha.ForeColor = System.Drawing.Color.Black;
            this.bttnMasWhiteMocha.Location = new System.Drawing.Point(79, 124);
            this.bttnMasWhiteMocha.Name = "bttnMasWhiteMocha";
            this.bttnMasWhiteMocha.Size = new System.Drawing.Size(30, 30);
            this.bttnMasWhiteMocha.TabIndex = 10;
            this.bttnMasWhiteMocha.Text = "+";
            this.bttnMasWhiteMocha.UseVisualStyleBackColor = false;
            this.bttnMasWhiteMocha.Click += new System.EventHandler(this.bttnMasWhiteMocha_Click);
            // 
            // bttnMenosWhiteMocha
            // 
            this.bttnMenosWhiteMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosWhiteMocha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosWhiteMocha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosWhiteMocha.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosWhiteMocha.Location = new System.Drawing.Point(18, 124);
            this.bttnMenosWhiteMocha.Name = "bttnMenosWhiteMocha";
            this.bttnMenosWhiteMocha.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosWhiteMocha.TabIndex = 9;
            this.bttnMenosWhiteMocha.Text = "-";
            this.bttnMenosWhiteMocha.UseVisualStyleBackColor = false;
            this.bttnMenosWhiteMocha.Click += new System.EventHandler(this.bttnMenosWhiteMocha_Click);
            // 
            // lablPrecioWhiteMocha
            // 
            this.lablPrecioWhiteMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioWhiteMocha.AutoSize = true;
            this.lablPrecioWhiteMocha.Location = new System.Drawing.Point(15, 181);
            this.lablPrecioWhiteMocha.Name = "lablPrecioWhiteMocha";
            this.lablPrecioWhiteMocha.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioWhiteMocha.TabIndex = 2;
            this.lablPrecioWhiteMocha.Text = "65.00";
            // 
            // bttnInfoWhiteMocha
            // 
            this.bttnInfoWhiteMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoWhiteMocha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoWhiteMocha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoWhiteMocha.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoWhiteMocha.Location = new System.Drawing.Point(93, 172);
            this.bttnInfoWhiteMocha.Name = "bttnInfoWhiteMocha";
            this.bttnInfoWhiteMocha.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoWhiteMocha.TabIndex = 1;
            this.bttnInfoWhiteMocha.Text = "i";
            this.bttnInfoWhiteMocha.UseVisualStyleBackColor = false;
            this.bttnInfoWhiteMocha.Click += new System.EventHandler(this.bttnInfoWhiteMocha_Click);
            // 
            // btnWhiteMocha
            // 
            this.btnWhiteMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnWhiteMocha.BackColor = System.Drawing.Color.White;
            this.btnWhiteMocha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWhiteMocha.BackgroundImage")));
            this.btnWhiteMocha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnWhiteMocha.Location = new System.Drawing.Point(13, 34);
            this.btnWhiteMocha.Name = "btnWhiteMocha";
            this.btnWhiteMocha.Size = new System.Drawing.Size(102, 80);
            this.btnWhiteMocha.TabIndex = 0;
            this.btnWhiteMocha.UseVisualStyleBackColor = false;
            // 
            // grpBLatte
            // 
            this.grpBLatte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBLatte.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBLatte.Controls.Add(this.lablCantidadLatte);
            this.grpBLatte.Controls.Add(this.bttnMasLatte);
            this.grpBLatte.Controls.Add(this.lablPrecioLatte);
            this.grpBLatte.Controls.Add(this.bttnMenosLatte);
            this.grpBLatte.Controls.Add(this.bttnInfoLatte);
            this.grpBLatte.Controls.Add(this.btnLatte);
            this.grpBLatte.Location = new System.Drawing.Point(611, 49);
            this.grpBLatte.Name = "grpBLatte";
            this.grpBLatte.Size = new System.Drawing.Size(129, 208);
            this.grpBLatte.TabIndex = 4;
            this.grpBLatte.TabStop = false;
            this.grpBLatte.Text = "Latte";
            // 
            // lablCantidadLatte
            // 
            this.lablCantidadLatte.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadLatte.AutoSize = true;
            this.lablCantidadLatte.Location = new System.Drawing.Point(57, 134);
            this.lablCantidadLatte.Name = "lablCantidadLatte";
            this.lablCantidadLatte.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadLatte.TabIndex = 8;
            this.lablCantidadLatte.Text = "0";
            // 
            // bttnMasLatte
            // 
            this.bttnMasLatte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasLatte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasLatte.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasLatte.ForeColor = System.Drawing.Color.Black;
            this.bttnMasLatte.Location = new System.Drawing.Point(77, 126);
            this.bttnMasLatte.Name = "bttnMasLatte";
            this.bttnMasLatte.Size = new System.Drawing.Size(30, 30);
            this.bttnMasLatte.TabIndex = 7;
            this.bttnMasLatte.Text = "+";
            this.bttnMasLatte.UseVisualStyleBackColor = false;
            this.bttnMasLatte.Click += new System.EventHandler(this.bttnMasLatte_Click);
            // 
            // lablPrecioLatte
            // 
            this.lablPrecioLatte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioLatte.AutoSize = true;
            this.lablPrecioLatte.Location = new System.Drawing.Point(15, 182);
            this.lablPrecioLatte.Name = "lablPrecioLatte";
            this.lablPrecioLatte.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioLatte.TabIndex = 2;
            this.lablPrecioLatte.Text = "80.00";
            // 
            // bttnMenosLatte
            // 
            this.bttnMenosLatte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosLatte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosLatte.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosLatte.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosLatte.Location = new System.Drawing.Point(18, 125);
            this.bttnMenosLatte.Name = "bttnMenosLatte";
            this.bttnMenosLatte.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosLatte.TabIndex = 6;
            this.bttnMenosLatte.Text = "-";
            this.bttnMenosLatte.UseVisualStyleBackColor = false;
            this.bttnMenosLatte.Click += new System.EventHandler(this.bttnMenosLatte_Click);
            // 
            // bttnInfoLatte
            // 
            this.bttnInfoLatte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoLatte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoLatte.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoLatte.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoLatte.Location = new System.Drawing.Point(93, 172);
            this.bttnInfoLatte.Name = "bttnInfoLatte";
            this.bttnInfoLatte.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoLatte.TabIndex = 1;
            this.bttnInfoLatte.Text = "i";
            this.bttnInfoLatte.UseVisualStyleBackColor = false;
            this.bttnInfoLatte.Click += new System.EventHandler(this.bttnInfoLatte_Click);
            // 
            // btnLatte
            // 
            this.btnLatte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLatte.BackColor = System.Drawing.Color.White;
            this.btnLatte.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLatte.BackgroundImage")));
            this.btnLatte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLatte.Location = new System.Drawing.Point(13, 34);
            this.btnLatte.Name = "btnLatte";
            this.btnLatte.Size = new System.Drawing.Size(102, 80);
            this.btnLatte.TabIndex = 0;
            this.btnLatte.UseVisualStyleBackColor = false;
            // 
            // grpBPastel
            // 
            this.grpBPastel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBPastel.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBPastel.Controls.Add(this.lablCantidadPastel);
            this.grpBPastel.Controls.Add(this.lablPrecioPastel);
            this.grpBPastel.Controls.Add(this.bttnMasPastel);
            this.grpBPastel.Controls.Add(this.bttbInfoPastel);
            this.grpBPastel.Controls.Add(this.bttnMenosPastel);
            this.grpBPastel.Controls.Add(this.btnPastel);
            this.grpBPastel.Location = new System.Drawing.Point(156, 50);
            this.grpBPastel.Name = "grpBPastel";
            this.grpBPastel.Size = new System.Drawing.Size(128, 208);
            this.grpBPastel.TabIndex = 8;
            this.grpBPastel.TabStop = false;
            this.grpBPastel.Text = "Pastel";
            // 
            // lablCantidadPastel
            // 
            this.lablCantidadPastel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadPastel.AutoSize = true;
            this.lablCantidadPastel.Location = new System.Drawing.Point(56, 131);
            this.lablCantidadPastel.Name = "lablCantidadPastel";
            this.lablCantidadPastel.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadPastel.TabIndex = 19;
            this.lablCantidadPastel.Text = "0";
            // 
            // lablPrecioPastel
            // 
            this.lablPrecioPastel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioPastel.AutoSize = true;
            this.lablPrecioPastel.Location = new System.Drawing.Point(17, 181);
            this.lablPrecioPastel.Name = "lablPrecioPastel";
            this.lablPrecioPastel.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioPastel.TabIndex = 2;
            this.lablPrecioPastel.Text = "50.00";
            // 
            // bttnMasPastel
            // 
            this.bttnMasPastel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasPastel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasPastel.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasPastel.ForeColor = System.Drawing.Color.Black;
            this.bttnMasPastel.Location = new System.Drawing.Point(81, 125);
            this.bttnMasPastel.Name = "bttnMasPastel";
            this.bttnMasPastel.Size = new System.Drawing.Size(30, 30);
            this.bttnMasPastel.TabIndex = 18;
            this.bttnMasPastel.Text = "+";
            this.bttnMasPastel.UseVisualStyleBackColor = false;
            this.bttnMasPastel.Click += new System.EventHandler(this.bttnMasPastel_Click);
            // 
            // bttbInfoPastel
            // 
            this.bttbInfoPastel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttbInfoPastel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttbInfoPastel.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttbInfoPastel.ForeColor = System.Drawing.Color.Blue;
            this.bttbInfoPastel.Location = new System.Drawing.Point(92, 172);
            this.bttbInfoPastel.Name = "bttbInfoPastel";
            this.bttbInfoPastel.Size = new System.Drawing.Size(30, 30);
            this.bttbInfoPastel.TabIndex = 1;
            this.bttbInfoPastel.Text = "i";
            this.bttbInfoPastel.UseVisualStyleBackColor = false;
            this.bttbInfoPastel.Click += new System.EventHandler(this.bttbInfoPastel_Click);
            // 
            // bttnMenosPastel
            // 
            this.bttnMenosPastel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosPastel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosPastel.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosPastel.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosPastel.Location = new System.Drawing.Point(13, 125);
            this.bttnMenosPastel.Name = "bttnMenosPastel";
            this.bttnMenosPastel.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosPastel.TabIndex = 17;
            this.bttnMenosPastel.Text = "-";
            this.bttnMenosPastel.UseVisualStyleBackColor = false;
            this.bttnMenosPastel.Click += new System.EventHandler(this.bttnMenosPastel_Click);
            // 
            // btnPastel
            // 
            this.btnPastel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnPastel.BackColor = System.Drawing.Color.White;
            this.btnPastel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPastel.BackgroundImage")));
            this.btnPastel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPastel.Location = new System.Drawing.Point(13, 34);
            this.btnPastel.Name = "btnPastel";
            this.btnPastel.Size = new System.Drawing.Size(102, 80);
            this.btnPastel.TabIndex = 0;
            this.btnPastel.UseVisualStyleBackColor = false;
            // 
            // grpBChocolate
            // 
            this.grpBChocolate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBChocolate.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBChocolate.Controls.Add(this.lablCantidadChocolate);
            this.grpBChocolate.Controls.Add(this.bttnMasChocolate);
            this.grpBChocolate.Controls.Add(this.bttnMenosChocolate);
            this.grpBChocolate.Controls.Add(this.lablPrecioChocolate);
            this.grpBChocolate.Controls.Add(this.bttnInfoChocolate);
            this.grpBChocolate.Controls.Add(this.btnChocolate);
            this.grpBChocolate.Location = new System.Drawing.Point(762, 49);
            this.grpBChocolate.Name = "grpBChocolate";
            this.grpBChocolate.Size = new System.Drawing.Size(129, 208);
            this.grpBChocolate.TabIndex = 5;
            this.grpBChocolate.TabStop = false;
            this.grpBChocolate.Text = "Chocolate";
            // 
            // lablCantidadChocolate
            // 
            this.lablCantidadChocolate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadChocolate.AutoSize = true;
            this.lablCantidadChocolate.Location = new System.Drawing.Point(55, 134);
            this.lablCantidadChocolate.Name = "lablCantidadChocolate";
            this.lablCantidadChocolate.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadChocolate.TabIndex = 11;
            this.lablCantidadChocolate.Text = "0";
            // 
            // bttnMasChocolate
            // 
            this.bttnMasChocolate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasChocolate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasChocolate.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasChocolate.ForeColor = System.Drawing.Color.Black;
            this.bttnMasChocolate.Location = new System.Drawing.Point(72, 126);
            this.bttnMasChocolate.Name = "bttnMasChocolate";
            this.bttnMasChocolate.Size = new System.Drawing.Size(30, 30);
            this.bttnMasChocolate.TabIndex = 10;
            this.bttnMasChocolate.Text = "+";
            this.bttnMasChocolate.UseVisualStyleBackColor = false;
            this.bttnMasChocolate.Click += new System.EventHandler(this.bttnMasChocolate_Click);
            // 
            // bttnMenosChocolate
            // 
            this.bttnMenosChocolate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosChocolate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosChocolate.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosChocolate.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosChocolate.Location = new System.Drawing.Point(21, 126);
            this.bttnMenosChocolate.Name = "bttnMenosChocolate";
            this.bttnMenosChocolate.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosChocolate.TabIndex = 9;
            this.bttnMenosChocolate.Text = "-";
            this.bttnMenosChocolate.UseVisualStyleBackColor = false;
            this.bttnMenosChocolate.Click += new System.EventHandler(this.bttnMenosChocolate_Click);
            // 
            // lablPrecioChocolate
            // 
            this.lablPrecioChocolate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioChocolate.AutoSize = true;
            this.lablPrecioChocolate.Location = new System.Drawing.Point(12, 183);
            this.lablPrecioChocolate.Name = "lablPrecioChocolate";
            this.lablPrecioChocolate.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioChocolate.TabIndex = 2;
            this.lablPrecioChocolate.Text = "60.00";
            // 
            // bttnInfoChocolate
            // 
            this.bttnInfoChocolate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoChocolate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoChocolate.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoChocolate.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoChocolate.Location = new System.Drawing.Point(93, 172);
            this.bttnInfoChocolate.Name = "bttnInfoChocolate";
            this.bttnInfoChocolate.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoChocolate.TabIndex = 1;
            this.bttnInfoChocolate.Text = "i";
            this.bttnInfoChocolate.UseVisualStyleBackColor = false;
            this.bttnInfoChocolate.Click += new System.EventHandler(this.bttnInfoChocolate_Click);
            // 
            // btnChocolate
            // 
            this.btnChocolate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnChocolate.BackColor = System.Drawing.Color.White;
            this.btnChocolate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChocolate.BackgroundImage")));
            this.btnChocolate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnChocolate.Location = new System.Drawing.Point(13, 34);
            this.btnChocolate.Name = "btnChocolate";
            this.btnChocolate.Size = new System.Drawing.Size(102, 80);
            this.btnChocolate.TabIndex = 0;
            this.btnChocolate.UseVisualStyleBackColor = false;
            // 
            // grpBSandwich
            // 
            this.grpBSandwich.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBSandwich.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBSandwich.Controls.Add(this.labelCantidadSandwich);
            this.grpBSandwich.Controls.Add(this.bttnMasSandwich);
            this.grpBSandwich.Controls.Add(this.bttnMenosSandwich);
            this.grpBSandwich.Controls.Add(this.lablPrecioSandwich);
            this.grpBSandwich.Controls.Add(this.bttnInfoSandwich);
            this.grpBSandwich.Controls.Add(this.btnSandwich);
            this.grpBSandwich.Location = new System.Drawing.Point(449, 50);
            this.grpBSandwich.Name = "grpBSandwich";
            this.grpBSandwich.Size = new System.Drawing.Size(129, 208);
            this.grpBSandwich.TabIndex = 7;
            this.grpBSandwich.TabStop = false;
            this.grpBSandwich.Text = "Sandwich";
            // 
            // labelCantidadSandwich
            // 
            this.labelCantidadSandwich.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.labelCantidadSandwich.AutoSize = true;
            this.labelCantidadSandwich.Location = new System.Drawing.Point(58, 130);
            this.labelCantidadSandwich.Name = "labelCantidadSandwich";
            this.labelCantidadSandwich.Size = new System.Drawing.Size(14, 13);
            this.labelCantidadSandwich.TabIndex = 11;
            this.labelCantidadSandwich.Text = "0";
            // 
            // bttnMasSandwich
            // 
            this.bttnMasSandwich.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasSandwich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasSandwich.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasSandwich.ForeColor = System.Drawing.Color.Black;
            this.bttnMasSandwich.Location = new System.Drawing.Point(84, 125);
            this.bttnMasSandwich.Name = "bttnMasSandwich";
            this.bttnMasSandwich.Size = new System.Drawing.Size(30, 30);
            this.bttnMasSandwich.TabIndex = 10;
            this.bttnMasSandwich.Text = "+";
            this.bttnMasSandwich.UseVisualStyleBackColor = false;
            this.bttnMasSandwich.Click += new System.EventHandler(this.bttnMasSandwich_Click);
            // 
            // bttnMenosSandwich
            // 
            this.bttnMenosSandwich.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosSandwich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosSandwich.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosSandwich.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosSandwich.Location = new System.Drawing.Point(13, 126);
            this.bttnMenosSandwich.Name = "bttnMenosSandwich";
            this.bttnMenosSandwich.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosSandwich.TabIndex = 9;
            this.bttnMenosSandwich.Text = "-";
            this.bttnMenosSandwich.UseVisualStyleBackColor = false;
            this.bttnMenosSandwich.Click += new System.EventHandler(this.bttnMenosSandwich_Click);
            // 
            // lablPrecioSandwich
            // 
            this.lablPrecioSandwich.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioSandwich.AutoSize = true;
            this.lablPrecioSandwich.Location = new System.Drawing.Point(24, 186);
            this.lablPrecioSandwich.Name = "lablPrecioSandwich";
            this.lablPrecioSandwich.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioSandwich.TabIndex = 2;
            this.lablPrecioSandwich.Text = "55.00";
            // 
            // bttnInfoSandwich
            // 
            this.bttnInfoSandwich.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoSandwich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoSandwich.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoSandwich.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoSandwich.Location = new System.Drawing.Point(93, 172);
            this.bttnInfoSandwich.Name = "bttnInfoSandwich";
            this.bttnInfoSandwich.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoSandwich.TabIndex = 1;
            this.bttnInfoSandwich.Text = "i";
            this.bttnInfoSandwich.UseVisualStyleBackColor = false;
            this.bttnInfoSandwich.Click += new System.EventHandler(this.bttnInfoSandwich_Click);
            // 
            // btnSandwich
            // 
            this.btnSandwich.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSandwich.BackColor = System.Drawing.Color.White;
            this.btnSandwich.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSandwich.BackgroundImage")));
            this.btnSandwich.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSandwich.Location = new System.Drawing.Point(13, 34);
            this.btnSandwich.Name = "btnSandwich";
            this.btnSandwich.Size = new System.Drawing.Size(102, 80);
            this.btnSandwich.TabIndex = 0;
            this.btnSandwich.UseVisualStyleBackColor = false;
            // 
            // grpBMocha
            // 
            this.grpBMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grpBMocha.BackColor = System.Drawing.Color.Gainsboro;
            this.grpBMocha.Controls.Add(this.lablCantidadMocha);
            this.grpBMocha.Controls.Add(this.bttnMasMocha);
            this.grpBMocha.Controls.Add(this.bttnMenosMocha);
            this.grpBMocha.Controls.Add(this.lablPrecioMocha);
            this.grpBMocha.Controls.Add(this.bttnInfoMocha);
            this.grpBMocha.Controls.Add(this.btnMocha);
            this.grpBMocha.Location = new System.Drawing.Point(325, 49);
            this.grpBMocha.Name = "grpBMocha";
            this.grpBMocha.Size = new System.Drawing.Size(128, 208);
            this.grpBMocha.TabIndex = 5;
            this.grpBMocha.TabStop = false;
            this.grpBMocha.Text = "Mocha";
            // 
            // lablCantidadMocha
            // 
            this.lablCantidadMocha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lablCantidadMocha.AutoSize = true;
            this.lablCantidadMocha.Location = new System.Drawing.Point(59, 135);
            this.lablCantidadMocha.Name = "lablCantidadMocha";
            this.lablCantidadMocha.Size = new System.Drawing.Size(14, 13);
            this.lablCantidadMocha.TabIndex = 11;
            this.lablCantidadMocha.Text = "0";
            // 
            // bttnMasMocha
            // 
            this.bttnMasMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMasMocha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMasMocha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMasMocha.ForeColor = System.Drawing.Color.Black;
            this.bttnMasMocha.Location = new System.Drawing.Point(79, 126);
            this.bttnMasMocha.Name = "bttnMasMocha";
            this.bttnMasMocha.Size = new System.Drawing.Size(30, 30);
            this.bttnMasMocha.TabIndex = 10;
            this.bttnMasMocha.Text = "+";
            this.bttnMasMocha.UseVisualStyleBackColor = false;
            this.bttnMasMocha.Click += new System.EventHandler(this.bttnMasMocha_Click);
            // 
            // bttnMenosMocha
            // 
            this.bttnMenosMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnMenosMocha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnMenosMocha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnMenosMocha.ForeColor = System.Drawing.Color.Black;
            this.bttnMenosMocha.Location = new System.Drawing.Point(16, 126);
            this.bttnMenosMocha.Name = "bttnMenosMocha";
            this.bttnMenosMocha.Size = new System.Drawing.Size(30, 30);
            this.bttnMenosMocha.TabIndex = 9;
            this.bttnMenosMocha.Text = "-";
            this.bttnMenosMocha.UseVisualStyleBackColor = false;
            this.bttnMenosMocha.Click += new System.EventHandler(this.bttnMenosMocha_Click);
            // 
            // lablPrecioMocha
            // 
            this.lablPrecioMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lablPrecioMocha.AutoSize = true;
            this.lablPrecioMocha.Location = new System.Drawing.Point(13, 181);
            this.lablPrecioMocha.Name = "lablPrecioMocha";
            this.lablPrecioMocha.Size = new System.Drawing.Size(39, 13);
            this.lablPrecioMocha.TabIndex = 2;
            this.lablPrecioMocha.Text = "65.00";
            // 
            // bttnInfoMocha
            // 
            this.bttnInfoMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bttnInfoMocha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.bttnInfoMocha.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnInfoMocha.ForeColor = System.Drawing.Color.Blue;
            this.bttnInfoMocha.Location = new System.Drawing.Point(92, 172);
            this.bttnInfoMocha.Name = "bttnInfoMocha";
            this.bttnInfoMocha.Size = new System.Drawing.Size(30, 30);
            this.bttnInfoMocha.TabIndex = 1;
            this.bttnInfoMocha.Text = "i";
            this.bttnInfoMocha.UseVisualStyleBackColor = false;
            this.bttnInfoMocha.Click += new System.EventHandler(this.bttnInfoMocha_Click);
            // 
            // btnMocha
            // 
            this.btnMocha.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMocha.BackColor = System.Drawing.Color.White;
            this.btnMocha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMocha.BackgroundImage")));
            this.btnMocha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMocha.Location = new System.Drawing.Point(13, 34);
            this.btnMocha.Name = "btnMocha";
            this.btnMocha.Size = new System.Drawing.Size(102, 80);
            this.btnMocha.TabIndex = 0;
            this.btnMocha.UseVisualStyleBackColor = false;
            // 
            // btnSalir
            // 
            this.btnSalir.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSalir.Location = new System.Drawing.Point(259, 7);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(81, 54);
            this.btnSalir.TabIndex = 22;
            this.btnSalir.Text = "Salir →";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnCancelarPedido
            // 
            this.btnCancelarPedido.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelarPedido.Location = new System.Drawing.Point(14, 6);
            this.btnCancelarPedido.Name = "btnCancelarPedido";
            this.btnCancelarPedido.Size = new System.Drawing.Size(82, 57);
            this.btnCancelarPedido.TabIndex = 21;
            this.btnCancelarPedido.Text = "Cancelar Pedido ❌";
            this.btnCancelarPedido.UseVisualStyleBackColor = true;
            this.btnCancelarPedido.Click += new System.EventHandler(this.btnCancelarPedido_Click);
            // 
            // dTPFecha
            // 
            this.dTPFecha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dTPFecha.CustomFormat = "dddd dd MMMM yyyy  hh:mm:ss";
            this.dTPFecha.Enabled = false;
            this.dTPFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTPFecha.Location = new System.Drawing.Point(1049, 23);
            this.dTPFecha.Name = "dTPFecha";
            this.dTPFecha.Size = new System.Drawing.Size(277, 20);
            this.dTPFecha.TabIndex = 20;
            // 
            // Logo
            // 
            this.Logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Logo.BackgroundImage")));
            this.Logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Logo.Location = new System.Drawing.Point(14, 11);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(76, 51);
            this.Logo.TabIndex = 17;
            this.Logo.TabStop = false;
            this.Logo.Click += new System.EventHandler(this.Logo_Click);
            // 
            // labelTotal
            // 
            this.labelTotal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(106, 425);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(57, 24);
            this.labelTotal.TabIndex = 19;
            this.labelTotal.Text = "Total";
            // 
            // txtMostrarTotal
            // 
            this.txtMostrarTotal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtMostrarTotal.Location = new System.Drawing.Point(170, 425);
            this.txtMostrarTotal.Name = "txtMostrarTotal";
            this.txtMostrarTotal.ReadOnly = true;
            this.txtMostrarTotal.Size = new System.Drawing.Size(144, 20);
            this.txtMostrarTotal.TabIndex = 18;
            // 
            // RTxtTicket
            // 
            this.RTxtTicket.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RTxtTicket.Location = new System.Drawing.Point(21, 49);
            this.RTxtTicket.Name = "RTxtTicket";
            this.RTxtTicket.ReadOnly = true;
            this.RTxtTicket.Size = new System.Drawing.Size(310, 370);
            this.RTxtTicket.TabIndex = 25;
            this.RTxtTicket.Text = "";
            // 
            // GrpBxAlimentos
            // 
            this.GrpBxAlimentos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GrpBxAlimentos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(185)))), ((int)(((byte)(155)))));
            this.GrpBxAlimentos.Controls.Add(this.grpBGalleta);
            this.GrpBxAlimentos.Controls.Add(this.grpBPastel);
            this.GrpBxAlimentos.Controls.Add(this.grpBBrownie);
            this.GrpBxAlimentos.Controls.Add(this.grpBSandwich);
            this.GrpBxAlimentos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpBxAlimentos.Location = new System.Drawing.Point(336, 311);
            this.GrpBxAlimentos.Name = "GrpBxAlimentos";
            this.GrpBxAlimentos.Size = new System.Drawing.Size(592, 286);
            this.GrpBxAlimentos.TabIndex = 26;
            this.GrpBxAlimentos.TabStop = false;
            this.GrpBxAlimentos.Text = "Alimentos";
            // 
            // GrpBxBebidasCalientes
            // 
            this.GrpBxBebidasCalientes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrpBxBebidasCalientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(152)))), ((int)(((byte)(108)))));
            this.GrpBxBebidasCalientes.Controls.Add(this.grpBWhiteMocha);
            this.GrpBxBebidasCalientes.Controls.Add(this.grpBAmericano);
            this.GrpBxBebidasCalientes.Controls.Add(this.grpBCappucino);
            this.GrpBxBebidasCalientes.Controls.Add(this.grpBLatte);
            this.GrpBxBebidasCalientes.Controls.Add(this.grpBMocha);
            this.GrpBxBebidasCalientes.Controls.Add(this.grpBChocolate);
            this.GrpBxBebidasCalientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpBxBebidasCalientes.Location = new System.Drawing.Point(8, 10);
            this.GrpBxBebidasCalientes.Name = "GrpBxBebidasCalientes";
            this.GrpBxBebidasCalientes.Size = new System.Drawing.Size(920, 295);
            this.GrpBxBebidasCalientes.TabIndex = 27;
            this.GrpBxBebidasCalientes.TabStop = false;
            this.GrpBxBebidasCalientes.Text = "Bebidas Calientes";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.GrpBxAlimentos);
            this.panel1.Controls.Add(this.GrpBxBebidasCalientes);
            this.panel1.Controls.Add(this.GrpBxBebidasFrias);
            this.panel1.Location = new System.Drawing.Point(14, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(935, 607);
            this.panel1.TabIndex = 28;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(193)))), ((int)(((byte)(181)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(93, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(774, 51);
            this.button1.TabIndex = 29;
            this.button1.Text = "Productos";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Silver;
            this.groupBox1.Controls.Add(this.datagribview1);
            this.groupBox1.Controls.Add(this.bntPedidoPara);
            this.groupBox1.Controls.Add(this.cmbPedido);
            this.groupBox1.Controls.Add(this.RTxtTicket);
            this.groupBox1.Controls.Add(this.txtMostrarTotal);
            this.groupBox1.Controls.Add(this.labelTotal);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(973, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 459);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pedido";
            // 
            // bntPedidoPara
            // 
            this.bntPedidoPara.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bntPedidoPara.BackColor = System.Drawing.Color.Gainsboro;
            this.bntPedidoPara.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntPedidoPara.Location = new System.Drawing.Point(41, 19);
            this.bntPedidoPara.Name = "bntPedidoPara";
            this.bntPedidoPara.Size = new System.Drawing.Size(113, 23);
            this.bntPedidoPara.TabIndex = 27;
            this.bntPedidoPara.Text = "Pedido para:";
            this.bntPedidoPara.UseVisualStyleBackColor = false;
            // 
            // cmbPedido
            // 
            this.cmbPedido.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbPedido.BackColor = System.Drawing.Color.Chartreuse;
            this.cmbPedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPedido.FormattingEnabled = true;
            this.cmbPedido.Items.AddRange(new object[] {
            "COMEDOR",
            "LLEVAR"});
            this.cmbPedido.Location = new System.Drawing.Point(157, 19);
            this.cmbPedido.Name = "cmbPedido";
            this.cmbPedido.Size = new System.Drawing.Size(153, 21);
            this.cmbPedido.TabIndex = 26;
            this.cmbPedido.Text = "Seleccionar";
            this.cmbPedido.SelectedIndexChanged += new System.EventHandler(this.cmbPedido_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.btnCancelarPedido);
            this.panel2.Controls.Add(this.BtnCompletarPedido);
            this.panel2.Controls.Add(this.btnSalir);
            this.panel2.Location = new System.Drawing.Point(973, 586);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(353, 69);
            this.panel2.TabIndex = 31;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.Logo);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.dTPFecha);
            this.panel3.Location = new System.Drawing.Point(-1, -2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1344, 678);
            this.panel3.TabIndex = 32;
            // 
            // datagribview1
            // 
            this.datagribview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagribview1.Location = new System.Drawing.Point(21, 49);
            this.datagribview1.Name = "datagribview1";
            this.datagribview1.Size = new System.Drawing.Size(310, 370);
            this.datagribview1.TabIndex = 28;
            // 
            // Menú
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1343, 675);
            this.Controls.Add(this.panel3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menú";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Drop Coffee ®";
            this.grpBBrownie.ResumeLayout(false);
            this.grpBBrownie.PerformLayout();
            this.grpBGalleta.ResumeLayout(false);
            this.grpBGalleta.PerformLayout();
            this.grpBFrappucciono.ResumeLayout(false);
            this.grpBFrappucciono.PerformLayout();
            this.GrpBxBebidasFrias.ResumeLayout(false);
            this.grpBTeaMatcha.ResumeLayout(false);
            this.grpBTeaMatcha.PerformLayout();
            this.grpBAmericano.ResumeLayout(false);
            this.grpBAmericano.PerformLayout();
            this.grpBCappucino.ResumeLayout(false);
            this.grpBCappucino.PerformLayout();
            this.grpBWhiteMocha.ResumeLayout(false);
            this.grpBWhiteMocha.PerformLayout();
            this.grpBLatte.ResumeLayout(false);
            this.grpBLatte.PerformLayout();
            this.grpBPastel.ResumeLayout(false);
            this.grpBPastel.PerformLayout();
            this.grpBChocolate.ResumeLayout(false);
            this.grpBChocolate.PerformLayout();
            this.grpBSandwich.ResumeLayout(false);
            this.grpBSandwich.PerformLayout();
            this.grpBMocha.ResumeLayout(false);
            this.grpBMocha.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.GrpBxAlimentos.ResumeLayout(false);
            this.GrpBxBebidasCalientes.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagribview1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lablCantidadTeaMatcha;
        private System.Windows.Forms.Label lablCantidadBrownie;
        private System.Windows.Forms.Label lablPrecioBrownie;
        private System.Windows.Forms.Button bttnMasBrownie;
        private System.Windows.Forms.GroupBox grpBBrownie;
        private System.Windows.Forms.Button bttnMenosBrownie;
        private System.Windows.Forms.Button bttnInfoBrownie;
        private System.Windows.Forms.Button btnBrownie;
        private System.Windows.Forms.GroupBox grpBGalleta;
        private System.Windows.Forms.Label lablCantidadGalleta;
        private System.Windows.Forms.Button bttnMasGallleta;
        private System.Windows.Forms.Button bttnMenosGalleta;
        private System.Windows.Forms.Label lablPrecioGalleta;
        private System.Windows.Forms.Button bttnInfoGalleta;
        private System.Windows.Forms.Button btnGalleta;
        private System.Windows.Forms.Button btnFrappucciono;
        private System.Windows.Forms.Button bttnMasFrapuccino;
        private System.Windows.Forms.Button bttnMenosFrapuccino;
        private System.Windows.Forms.Label lablCantidadFrapuccino;
        private System.Windows.Forms.Label lablPrecioFrappucciono;
        private System.Windows.Forms.GroupBox grpBFrappucciono;
        private System.Windows.Forms.Button bttnInfoFrappucciono;
        private System.Windows.Forms.Button BtnCompletarPedido;
        private System.Windows.Forms.Button bttnMasTeaMatcha;
        private System.Windows.Forms.GroupBox GrpBxBebidasFrias;
        private System.Windows.Forms.GroupBox grpBAmericano;
        private System.Windows.Forms.Label lablCantidadAmericano;
        private System.Windows.Forms.Button bttnMasAmericano;
        private System.Windows.Forms.Button bttnMenosAmericano;
        private System.Windows.Forms.Label lablPrecioAmericano;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnAmericano;
        private System.Windows.Forms.GroupBox grpBCappucino;
        private System.Windows.Forms.Label lablCantidadCapuccino;
        private System.Windows.Forms.Label lablPrecioCappucino;
        private System.Windows.Forms.Button bttnMasCapuccino;
        private System.Windows.Forms.Button bttnInfoCappucino;
        private System.Windows.Forms.Button bttnMenosCappuccino;
        private System.Windows.Forms.Button btnCappucino;
        private System.Windows.Forms.GroupBox grpBWhiteMocha;
        private System.Windows.Forms.Label lablCantidadWhiteMocha;
        private System.Windows.Forms.Button bttnMasWhiteMocha;
        private System.Windows.Forms.Button bttnMenosWhiteMocha;
        private System.Windows.Forms.Label lablPrecioWhiteMocha;
        private System.Windows.Forms.Button bttnInfoWhiteMocha;
        private System.Windows.Forms.Button btnWhiteMocha;
        private System.Windows.Forms.GroupBox grpBLatte;
        private System.Windows.Forms.Label lablCantidadLatte;
        private System.Windows.Forms.Button bttnMasLatte;
        private System.Windows.Forms.Label lablPrecioLatte;
        private System.Windows.Forms.Button bttnMenosLatte;
        private System.Windows.Forms.Button bttnInfoLatte;
        private System.Windows.Forms.Button btnLatte;
        private System.Windows.Forms.GroupBox grpBTeaMatcha;
        private System.Windows.Forms.Button bttnMenosTeaMatcha;
        private System.Windows.Forms.Label lablPrecioTeaMatcha;
        private System.Windows.Forms.Button bttnInfoTeaMatcha;
        private System.Windows.Forms.Button btnTeaMatcha;
        private System.Windows.Forms.GroupBox grpBPastel;
        private System.Windows.Forms.Label lablCantidadPastel;
        private System.Windows.Forms.Label lablPrecioPastel;
        private System.Windows.Forms.Button bttnMasPastel;
        private System.Windows.Forms.Button bttbInfoPastel;
        private System.Windows.Forms.Button bttnMenosPastel;
        private System.Windows.Forms.Button btnPastel;
        private System.Windows.Forms.GroupBox grpBChocolate;
        private System.Windows.Forms.Label lablCantidadChocolate;
        private System.Windows.Forms.Button bttnMasChocolate;
        private System.Windows.Forms.Button bttnMenosChocolate;
        private System.Windows.Forms.Label lablPrecioChocolate;
        private System.Windows.Forms.Button bttnInfoChocolate;
        private System.Windows.Forms.Button btnChocolate;
        private System.Windows.Forms.GroupBox grpBSandwich;
        private System.Windows.Forms.Label labelCantidadSandwich;
        private System.Windows.Forms.Button bttnMasSandwich;
        private System.Windows.Forms.Button bttnMenosSandwich;
        private System.Windows.Forms.Label lablPrecioSandwich;
        private System.Windows.Forms.Button bttnInfoSandwich;
        private System.Windows.Forms.Button btnSandwich;
        private System.Windows.Forms.GroupBox grpBMocha;
        private System.Windows.Forms.Label lablCantidadMocha;
        private System.Windows.Forms.Button bttnMasMocha;
        private System.Windows.Forms.Button bttnMenosMocha;
        private System.Windows.Forms.Label lablPrecioMocha;
        private System.Windows.Forms.Button bttnInfoMocha;
        private System.Windows.Forms.Button btnMocha;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnCancelarPedido;
        private System.Windows.Forms.DateTimePicker dTPFecha;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.TextBox txtMostrarTotal;
        private System.Windows.Forms.RichTextBox RTxtTicket;
        private System.Windows.Forms.GroupBox GrpBxAlimentos;
        private System.Windows.Forms.GroupBox GrpBxBebidasCalientes;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbPedido;
        private System.Windows.Forms.Button bntPedidoPara;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView datagribview1;
    }
}